Mappings
/mystore/register/grocer
mystore/register/consumer
/mystore/stocklist/{location}
/mystore/stocklist/items/{item}