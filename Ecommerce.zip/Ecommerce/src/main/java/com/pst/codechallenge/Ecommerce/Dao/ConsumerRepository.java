package com.pst.codechallenge.Ecommerce.Dao;
/*
 * This is Jpa repository to perform curd operations for Consumer resource
 */
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pst.codechallenge.Ecommerce.entity.Consumer;

@Repository

public interface ConsumerRepository extends JpaRepository<Consumer, Integer>{

}
