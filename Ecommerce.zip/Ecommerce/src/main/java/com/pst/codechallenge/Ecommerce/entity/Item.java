package com.pst.codechallenge.Ecommerce.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Item {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private int id;
	
	private String itemname;

	public Item() {
		
	}
	public Item( String itemname) {
		super();
		this.itemname = itemname;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	@Override
	public String toString() {
		return "Item [id=" + id + ", itemname=" + itemname + "]";
	}
	
	
}
