package com.pst.codechallenge.Ecommerce.service;

import java.util.List;

import com.pst.codechallenge.Ecommerce.entity.Consumer;
import com.pst.codechallenge.Ecommerce.entity.Grocer;
import com.pst.codechallenge.Ecommerce.entity.Item;

public interface IRegisterService {
    //for saving Consumer
	String save(Consumer user);

	//for saving Grocer
	String save(Grocer user);
	
}
