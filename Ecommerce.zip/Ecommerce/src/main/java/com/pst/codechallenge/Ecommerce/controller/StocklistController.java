package com.pst.codechallenge.Ecommerce.controller;

/*
 * This is RestController for getting stock list available by location, by item
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pst.codechallenge.Ecommerce.entity.Grocer;
import com.pst.codechallenge.Ecommerce.service.IRegisterService;
import com.pst.codechallenge.Ecommerce.service.IStocklistService;

@RestController

@RequestMapping("/stocklist")
public class StocklistController {

	@Autowired
	private IStocklistService stockService;
	
	@GetMapping("/{location}")
	public List<Grocer> getGrocers(@PathVariable("location") String location ) {
		
		return stockService.findAllByLocation(location);
	}
	@RequestMapping("/items/{item}")
	public List<Grocer> getGrocersWho(@PathVariable("item") String item ) {
		return stockService.findAllByItem(item);
	}
}
