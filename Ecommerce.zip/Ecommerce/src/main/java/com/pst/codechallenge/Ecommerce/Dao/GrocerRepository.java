package com.pst.codechallenge.Ecommerce.Dao;
/*
 * This is Jpa repository to perform curd operations for Grocer resource
 */
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.pst.codechallenge.Ecommerce.entity.Grocer;
import com.pst.codechallenge.Ecommerce.entity.Item;

@Repository
public interface GrocerRepository extends JpaRepository<Grocer, Integer>{

	List<Grocer> findAllByLocationIgnoreCase(String location);

	@Query("Select g  From Grocer g JOIN g.items i where itemname=?1")
	List<Grocer> findAllGrocersByItems(String item);
}
