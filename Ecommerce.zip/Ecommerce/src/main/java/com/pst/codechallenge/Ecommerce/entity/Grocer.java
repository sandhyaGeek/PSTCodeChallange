package com.pst.codechallenge.Ecommerce.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Grocer {
	 @Id
	 @GeneratedValue(strategy=GenerationType.IDENTITY)
	    private int id;
	
		private String name;
	    private String location;
	    
		@OneToMany(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
		@JoinColumn(name="grocer_id")
		private List<Item> items;
	    
		public Grocer() {
			super();
		}
		public Grocer(String name, String location, List<Item> items) {
			this.name = name;
			this.location = location;
			this.items = items;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
	    public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public List<Item> getItems() {
			return items;
		}
		public void setItems(List<Item> items) {
			this.items = items;
		}
		@Override
		public String toString() {
			return "Grocer [id=" + id + ", name=" + name + ", location=" + location + ", items=" + items + "]";
		}
	
}
