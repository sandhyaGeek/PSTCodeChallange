package com.pst.codechallenge.Ecommerce.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pst.codechallenge.Ecommerce.Dao.GrocerRepository;
import com.pst.codechallenge.Ecommerce.entity.Grocer;
import com.pst.codechallenge.Ecommerce.exception.GrocerListNotFound;

@Service
public class StocklistServiceImpl implements IStocklistService {

	@Autowired
	private GrocerRepository grocerRepo;
	@Override
	@Transactional
	public List<Grocer> findAllByLocation(String location) {
		
		List<Grocer> grocerlist = grocerRepo.findAllByLocationIgnoreCase(location);
		if(grocerlist==null || grocerlist.size()==0) {
			throw new GrocerListNotFound("not found");
		}
		return grocerlist;
	}

	@Override
	@Transactional
	public List<Grocer> findAllByItem(String item) {
	
		List<Grocer> grocerlist = grocerRepo.findAllGrocersByItems(item);
		if(grocerlist==null || grocerlist.size()==0) {
			throw new GrocerListNotFound("not found");
		}
		return grocerlist;

	}
}
