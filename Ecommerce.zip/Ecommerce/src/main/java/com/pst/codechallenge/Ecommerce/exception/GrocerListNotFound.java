package com.pst.codechallenge.Ecommerce.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class GrocerListNotFound extends RuntimeException {

	public GrocerListNotFound(String msg) {
		super(msg);
	}
}
