package com.pst.codechallenge.Ecommerce.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.text.CharacterPredicates;
import org.apache.commons.text.RandomStringGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pst.codechallenge.Ecommerce.Dao.ConsumerRepository;
import com.pst.codechallenge.Ecommerce.Dao.GrocerRepository;

import com.pst.codechallenge.Ecommerce.entity.Consumer;
import com.pst.codechallenge.Ecommerce.entity.Grocer;
import com.pst.codechallenge.Ecommerce.entity.Item;


@Service
public class RegisterServiceImp implements IRegisterService {

	@Autowired
	private ConsumerRepository repo;
	@Autowired
	private GrocerRepository grocerRepo;
	
	@Override
	@Transactional
	public String save(Consumer user) {
		
		Consumer savedUser = repo.save(user);
		
		return randomStringGenerator();
	}
	
	@Transactional
	public String save(Grocer user) {
		
		Grocer savedUser = grocerRepo.save(user);
		
		return randomStringGenerator();
	}


	
	public static String randomStringGenerator() {
		  RandomStringGenerator generator = new RandomStringGenerator.Builder()
		            .withinRange('0', 'z')
		            .filteredBy(CharacterPredicates.DIGITS, CharacterPredicates.LETTERS)
		            .build();
		return generator.generate(16);
	}
	
	//Incase of failure return a HTTP 500
}
