package com.pst.codechallenge.Ecommerce.service;

import java.util.List;

import com.pst.codechallenge.Ecommerce.entity.Grocer;

public interface IStocklistService {
	//fetching all Grocers by location
	List<Grocer> findAllByLocation(String location);

	//fetching all Grocers by item
	List<Grocer> findAllByItem(String item);
	
}
