insert into consumer values(1,'AZ','sandhya');
insert into consumer values(2,'AZ','rani');
