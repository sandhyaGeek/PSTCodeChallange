package com.pst.codechallenge.Ecommerce;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.pst.codechallenge.Ecommerce.controller.RegisterController;
import com.pst.codechallenge.Ecommerce.controller.StocklistController;
import com.pst.codechallenge.Ecommerce.entity.Grocer;
import com.pst.codechallenge.Ecommerce.entity.Item;
import com.pst.codechallenge.Ecommerce.service.IRegisterService;
import com.pst.codechallenge.Ecommerce.service.IStocklistService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = StocklistController.class)
public class StocklistControllerTest {

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private IStocklistService stockService;
	@MockBean
	private IRegisterService registerService;
	static Grocer grocer;
	static {
		Item item1= new Item("MacBook");
		Item item2= new Item("Ipad");
		Item item3= new Item("airpods");
		Item item4= new Item("MacBook Air");
		Item item5= new Item("MacBook Pro");
		List<Item> items = new ArrayList<Item>();
		items.add(item1);
		items.add(item2);
		items.add(item3);
		items.add(item4);
		items.add(item5);
		grocer = new Grocer("AppleStore","AZ",items);
	}
	@Test
	public  void getGrocersByLocation() throws Exception {
		registerService.save(grocer);
		List<Grocer> grocers = new ArrayList();
		grocers.add(grocer);
	   Mockito.when(stockService.findAllByLocation("AZ")).thenReturn(grocers);
		
		String uri = "/mystore/stocklist/AZ";
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri)
																.accept(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		
		assertEquals(HttpStatus.OK.value(),response.getStatus());
	
	}
	@Test
	public  void getGrocersByItem() throws Exception {
		registerService.save(grocer);
		List<Grocer> grocers = new ArrayList();
		grocers.add(grocer);
	   Mockito.when(stockService.findAllByItem("MacBook Air")).thenReturn(grocers);
		
		String uri = "/mystore/stocklist/items/MacBook Air";
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri)
																.accept(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		
		assertEquals(HttpStatus.OK.value(),response.getStatus());
	
	}
}
