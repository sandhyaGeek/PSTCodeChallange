package com.pst.codechallenge.Ecommerce;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pst.codechallenge.Ecommerce.controller.RegisterController;
import com.pst.codechallenge.Ecommerce.entity.Consumer;
import com.pst.codechallenge.Ecommerce.entity.Grocer;
import com.pst.codechallenge.Ecommerce.entity.Item;
import com.pst.codechallenge.Ecommerce.service.IRegisterService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = RegisterController.class)
public class RegisterControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private IRegisterService registerService;
	

	@Test
	public  void testCreateConsumer() throws Exception {
		Consumer mockUser = new Consumer("Sandhya","AZ");
		
		String inputInJson = this.mapToJson(mockUser);
		
		String uri = "/mystore/register/consumer";
		Mockito.when(registerService.save(Mockito.any(Consumer.class))).thenReturn(inputInJson);
		
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(uri)
																.accept(MediaType.APPLICATION_JSON).content(inputInJson)
																.contentType(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		
		assertEquals(HttpStatus.OK.value(),response.getStatus());
	}
	private String mapToJson(Object object) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(object);
	}
	
	@Test
	public  void testCreateGrocer() throws Exception {
		Item item1= new Item("MacBook");
		Item item2= new Item("Ipad");
		Item item3= new Item("airpods");
		Item item4= new Item("MacBook Air");
		Item item5= new Item("MacBook Pro");
		List<Item> items = new ArrayList<Item>();
		items.add(item1);
		items.add(item2);
		items.add(item3);
		items.add(item4);
		items.add(item5);
		Grocer mockUser = new Grocer("AppleStore","AZ",items);
		
		String inputInJson = this.mapToJson(mockUser);
		
		String uri = "/mystore/register/consumer";
		Mockito.when(registerService.save(Mockito.any(Grocer.class))).thenReturn(inputInJson);
		
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(uri)
																.accept(MediaType.APPLICATION_JSON).content(inputInJson)
																.contentType(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		
		assertEquals(HttpStatus.OK.value(),response.getStatus());
	}
}
